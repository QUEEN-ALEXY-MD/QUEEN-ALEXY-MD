function _classPrivateMethodSet() {
  throw new TypeError("attempted to reassign private method");
}

module.exports = _classPrivateMethodSet, module.exports.__esModule = true, module.exports["default"] = module.exports;