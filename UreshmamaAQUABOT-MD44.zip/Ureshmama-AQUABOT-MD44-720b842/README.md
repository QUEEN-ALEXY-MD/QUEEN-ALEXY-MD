# AQUABOT-MD
This project is still being tested
<p align="center"> <a href="github.com/sanuwaofficial"><img align="center" src="https://telegra.ph/file/85fe740b2385a55178500.jpg"/></a>
 <p align="center">
<a href="https://github.com/sanuwaofficial/AQUABOT-MD"><img title="Followers" src="https://img.shields.io/github/followers/sanuwaofficial?e=flat-square"></a>
<a href="https://github.com/sanuwaofficial/AQUABOT-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/sanuwaofficial/AQUABOT-MD?color=blue&style=flat-square"></a>
<a href="https://github.com/sanuwaofficial/AQUABOT-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/sanuwaofficial/AQUABOT-MD?color=red&style=flat-square"></a>
<a href="https://github.com/sanuwaofficial/AQUABOT-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/sanuwaofficial/AQUABOT-MD?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://github.com/sanuwaofficial/AQUABOT-MD"><img title="Size" src="https://img.shields.io/github/repo-size/sanuwaofficial/AQUABOT-MD?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/sanuwaofficial/AQUABOT-MD&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
<a href="https://github.com/sanuwaofficial/AQUABOT-MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
    </p>
    
  ### ඔබට පහසුවෙන් QR කේතය Repl.it මඟින් ලබා ගත හැක.. පහල බටනය CLICK කරන්න

[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@MagmaGaming/AQUABOT-MDV2?v=1)

## QR කේතය ලබා ගත් පසු Bot deploy කිරීමට පහල බටනය CLICK කරන්න..
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/sanuwaofficial/AQUABOT-MD)

---------------------------------   

 ###  Developer :- Sanuwa-official 

## Thanks To
- [@adiwajshing](https://github.com/adiwajshing/) for coded [Baileys](https://github.com/adiwajshing/Baileys) 
- [@yusufusta](https://github.com/yusufusta/) for coded [WhatsAsena](https://github.com/yusufusta/WhatsAsena) 
- [@sisula](https://github.com/sisula/) & [@joka](https://github.com/MrJoka-Thejaka/) for all the helps 🤝
 
  
 
